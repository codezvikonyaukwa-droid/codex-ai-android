package com.codexai.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private SpeechRecognizer speech;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private static final String MODEL = "gemini-3.5-flash-lite";
    private static final String KEY_ALIAS = "codex_ai_api_key_v1";
    private static final String PREFS = "codex_secure_prefs";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(10, 14, 25));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(10, 14, 25));
        web = new WebView(this);
        web.setBackgroundColor(android.graphics.Color.rgb(10, 14, 25));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Codex");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(Locale.getDefault()); });
    }

    private void js(String script) { runOnUiThread(() -> { if (web != null) web.evaluateJavascript(script, null); }); }
    private static String quote(String s) { return JSONObject.quote(s == null ? "" : s); }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance("AES", "AndroidKeyStore");
        android.security.keystore.KeyGenParameterSpec spec = new android.security.keystore.KeyGenParameterSpec.Builder(KEY_ALIAS,
            android.security.keystore.KeyProperties.PURPOSE_ENCRYPT | android.security.keystore.KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build();
        kg.init(spec); return kg.generateKey();
    }
    private void storeKey(String plain) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        byte[] encrypted = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        byte[] iv = c.getIV();
        byte[] all = new byte[iv.length + encrypted.length]; System.arraycopy(iv,0,all,0,iv.length); System.arraycopy(encrypted,0,all,iv.length,encrypted.length);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("api_key", Base64.encodeToString(all, Base64.NO_WRAP)).apply();
    }
    private String readKey() {
        try {
            String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString("api_key", ""); if (saved.isEmpty()) return "";
            byte[] all = Base64.decode(saved, Base64.NO_WRAP); byte[] iv = new byte[12]; byte[] enc = new byte[all.length-12];
            System.arraycopy(all,0,iv,0,12); System.arraycopy(all,12,enc,0,enc.length);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
            return new String(c.doFinal(enc), StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }

    private String requestGemini(String prompt) throws Exception {
        String key = readKey(); if (key.isEmpty()) throw new Exception("Add your Gemini API key in Settings first.");
        JSONObject body = new JSONObject();
        JSONArray parts = new JSONArray().put(new JSONObject().put("text", "You are CODEX AI, a helpful mobile coding assistant. If asked to create or modify code, return a complete solution. When generating a file, start with FILENAME: filename.ext then a fenced code block. Explain important steps briefly. Never claim code was executed or tested unless it actually was. Do not generate malware, credential theft, or harmful code.\n\nUser request:\n" + prompt));
        body.put("contents", new JSONArray().put(new JSONObject().put("role","user").put("parts",parts)));
        body.put("generationConfig", new JSONObject().put("temperature",0.25).put("maxOutputTokens",8192));
        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + MODEL + ":generateContent");
        HttpURLConnection con = (HttpURLConnection) url.openConnection(); con.setRequestMethod("POST"); con.setConnectTimeout(20000); con.setReadTimeout(90000); con.setDoOutput(true);
        con.setRequestProperty("Content-Type","application/json"); con.setRequestProperty("x-goog-api-key",key);
        try (java.io.OutputStream os = con.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = con.getResponseCode(); InputStream is = code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream();
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[4096]; int n; while ((n=is.read(buf))!=-1) out.write(buf,0,n); is.close();
        String raw = out.toString("UTF-8");
        if (code < 200 || code >= 300) throw new Exception("Gemini API error (HTTP " + code + "): " + raw.substring(0, Math.min(700, raw.length())));
        JSONObject data = new JSONObject(raw); JSONArray candidates = data.optJSONArray("candidates");
        if (candidates == null || candidates.length()==0) throw new Exception("The AI returned no answer. Try again.");
        JSONObject content = candidates.getJSONObject(0).optJSONObject("content"); JSONArray responseParts = content == null ? null : content.optJSONArray("parts");
        StringBuilder answer = new StringBuilder(); if (responseParts != null) for (int i=0;i<responseParts.length();i++) answer.append(responseParts.getJSONObject(i).optString("text",""));
        if (answer.length()==0) throw new Exception("The AI returned an empty answer. Try a different request."); return answer.toString();
    }

    private class Bridge {
        @JavascriptInterface public boolean hasKey() { return !readKey().isEmpty(); }
        @JavascriptInterface public void setKey(String key) {
            try { if (key == null || !key.trim().startsWith("AIza") || key.trim().length()<20) throw new Exception("That key doesn't look like a Google AI API key."); storeKey(key.trim()); js("onKeySaved(true,'API key saved securely on this device.')"); }
            catch (Exception e) { js("onKeySaved(false,"+quote(e.getMessage())+")"); }
        }
        @JavascriptInterface public void ask(String prompt, String requestId) {
            worker.submit(() -> { try { String answer = requestGemini(prompt); js("onAnswer("+quote(requestId)+",true,"+quote(answer)+")"); }
                catch (Exception e) { js("onAnswer("+quote(requestId)+",false,"+quote(e.getMessage())+")"); } });
        }
        @JavascriptInterface public void saveProject(String name, String content) {
            try {
                String safe = name == null ? "project.txt" : name.replaceAll("[^A-Za-z0-9._-]", "_");
                if (safe.isEmpty() || safe.startsWith(".")) safe = "project.txt";
                File dir = new File(getFilesDir(), "projects"); if (!dir.exists()) dir.mkdirs();
                File target = new File(dir, safe); try (FileOutputStream fos = new FileOutputStream(target)) { fos.write(content.getBytes(StandardCharsets.UTF_8)); }
                js("onProjectSaved(true,"+quote("Saved " + safe)+")");
            } catch (Exception e) { js("onProjectSaved(false,"+quote(e.getMessage())+")"); }
        }
        @JavascriptInterface public String listProjects() {
            JSONArray arr = new JSONArray(); File dir = new File(getFilesDir(),"projects"); File[] files = dir.listFiles();
            if (files != null) for (File f: files) if (f.isFile()) arr.put(f.getName()); return arr.toString();
        }
        @JavascriptInterface public String loadProject(String name) {
            try { String safe = name.replaceAll("[^A-Za-z0-9._-]", "_"); File f = new File(new File(getFilesDir(),"projects"),safe);
                if (!f.isFile()) return ""; java.io.FileInputStream in = new java.io.FileInputStream(f); ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] b=new byte[2048]; int n; while((n=in.read(b))!=-1) out.write(b,0,n); in.close(); return out.toString("UTF-8");
            } catch (Exception e) { return ""; }
        }
        @JavascriptInterface public void copy(String value) { runOnUiThread(() -> { ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("CODEX AI",value)); Toast.makeText(MainActivity.this,"Copied to clipboard",Toast.LENGTH_SHORT).show(); }); }
        @JavascriptInterface public void speak(String value) { runOnUiThread(() -> { if (tts != null) { tts.setLanguage(Locale.getDefault()); tts.speak(value,TextToSpeech.QUEUE_FLUSH,null,"codex_reply"); } }); }
        @JavascriptInterface public void listen() { runOnUiThread(() -> startListening()); }
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { js("onVoiceResult(false,'Speech recognition is not available on this phone.')"); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 51); return; }
        try {
            if (speech != null) { speech.destroy(); speech=null; }
            speech = SpeechRecognizer.createSpeechRecognizer(this);
            speech.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle p) { js("onVoiceStatus('Listening…')"); }
                public void onBeginningOfSpeech() {} public void onRmsChanged(float r) {} public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() { js("onVoiceStatus('Processing voice…')"); }
                public void onError(int e) { js("onVoiceResult(false,'Could not hear that. Tap the microphone and try again.')"); }
                public void onResults(Bundle b) { ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); js("onVoiceResult("+(a!=null&&!a.isEmpty())+","+quote(a!=null&&!a.isEmpty()?a.get(0):"")+")"); }
                public void onPartialResults(Bundle b) {} public void onEvent(int t, Bundle p) {}
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault()); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak to CODEX AI"); speech.startListening(i);
        } catch (Exception e) { js("onVoiceResult(false,'Voice input failed. Try again.')"); }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) { super.onRequestPermissionsResult(requestCode,permissions,grantResults); if(requestCode==51 && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) startListening(); else if(requestCode==51) js("onVoiceResult(false,'Microphone permission is needed for voice input.')"); }
    @Override public void onDestroy() { if (speech!=null) speech.destroy(); if(tts!=null) tts.shutdown(); worker.shutdownNow(); if(web!=null) web.destroy(); super.onDestroy(); }
}
