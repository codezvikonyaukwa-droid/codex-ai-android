# CODEX AI for Android

A native Android wrapper with a mobile coding-assistant UI, Gemini API integration, voice input, spoken replies, encrypted local API-key storage (Android Keystore AES-GCM), and private project saving.

## Build the APK

The source is an Android Studio/Gradle project. This workspace did not have the Android SDK or network access to download it, so the APK must be compiled in Android Studio or GitHub Actions.

### Build with Android Studio
1. Open this folder in Android Studio.
2. Install Android SDK Platform 35 if prompted.
3. Wait for Gradle sync.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

### Build with GitHub Actions
1. Create a GitHub repository and upload the contents of this folder to the repository root.
2. Open the repository's **Actions** tab and run **Build CODEX AI APK** (or push to `main`/`master`).
3. Open the successful workflow run and download the `CODEX-AI-debug-apk` artifact. Extract it to get `app-debug.apk`.
4. Transfer the APK to the Android phone, open it, and allow installation from that source if Android asks.

## Use
1. Install and open CODEX AI.
2. Tap Settings and add a Google Gemini API key from Google AI Studio.
3. Ask for code or app help. Generated code can be copied, saved as a project, or sent back for improvement.
4. Use the microphone for speech-to-text and Read reply for text-to-speech.

## Notes
- Requires Android 8.0 or newer and an internet connection for Gemini requests.
- The app does not bundle an API key. You supply your own; Google's API quotas and model access apply.
- This is a debug APK build configuration, not a Play Store release. Before public release, add a release signing key, privacy policy, thorough device testing, and any applicable compliance work.
